# COMPAG CJ r92 inference sample

This is the author-selected r92 native inference closure. It scores ordered 93-feature tables with XGBoost 2.1.1 and a fitted median imputer. The model was not refitted or numerically modified for this sample. Threshold 0.50 is the declared paper/example decision rule; 0.5843676924705505 is a stored legacy training-selected threshold and is optional only when explicitly selected.

The embedded prototype/PCA arrays belong to this historical model closure (ResNet50 IMAGENET1K_V2, 2048 to 32 dimensions). Exact transform fit row counts are unknown. This archive does not contain images, labels, research rows, SAM2, ResNet50 weights, YOLO weights, or a complete image workflow. A synthetic software fixture does not measure cotton-jassid accuracy.

The original private preset used `canonical-xgb-recall-gpu-v1` for Stage-20 transfer assistance. This separate sample adds a CPU tabular adapter. CPU scoring is a named execution variant; it is not an RTX 4090 historical replay.

Rights/status: the author selected this narrow r92 payload for a proposed public example. Specific model-weight ownership, coauthor/institutional approval, derivative distribution terms and any upstream-training-data conditions remain to be confirmed before external publication. Existing code licence text alone does not grant model-weight rights. No release URL or DOI exists in this candidate.
