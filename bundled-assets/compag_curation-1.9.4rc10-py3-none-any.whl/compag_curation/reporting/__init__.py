"""Reporting namespace."""
