"""Training namespace."""
