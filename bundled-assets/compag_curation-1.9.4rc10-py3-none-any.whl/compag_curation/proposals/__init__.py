"""Proposals namespace."""
