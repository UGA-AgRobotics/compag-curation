"""Inference namespace."""
